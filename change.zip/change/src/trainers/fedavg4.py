from src.trainers.base import BaseTrainer
from src.models.model import choose_model
from src.models.worker import LrdWorker
from src.optimizers.gd import GD
import numpy as np
import torch
import sys
import pickle
import math
criterion = torch.nn.CrossEntropyLoss()


class FedAvg4Trainer(BaseTrainer):
    """
    Scheme I and Scheme II, based on the flag of self.simple_average
    """
    def __init__(self, options, dataset):
        model = choose_model(options)
        self.move_model_to_gpu(model, options)

        self.optimizer = GD(model.parameters(), lr=options['lr'], weight_decay=options['wd'], momentum=options['momentum'])
        self.num_epoch = options['num_epoch']
        worker = LrdWorker(model, self.optimizer, options)  #这里用的是LrdWorker,调用之后做的工作就是加了一个计算网络参数。worker的初始化。
        super(FedAvg4Trainer, self).__init__(options, dataset, worker=worker)
        self.prob = self.compute_prob()

    def train(self):
        print('>>> Select {} clients per round \n'.format(self.clients_per_round))

        # Fetch latest flat model parameter
        train_acc=[]
        train_loss=[]
        test_acc=[]
        test_loss=[]
        size_ratios=[]
        sum_size=0
        sum_bsize=0
        self.latest_model = self.worker.get_flat_model_params()#调用woker.py中的get_flat_model_params()方法 在这个方法中已经使用了detach. 
        self.solution_diff_avg = torch.zeros_like(self.latest_model)
        for round_i in range(self.num_round):#start epoch
            # Test latest model on train data
            train_states=self.test_latest_model_on_traindata(round_i)#调用base.py 在训练数据上，更新全局模型梯度和状态
            test_states=self.test_latest_model_on_evaldata(round_i)#同上，每5次在测试数据上 更新全局模型的测试梯度状态
            # Choose K clients prop to data size
            if self.simple_average:
                selected_clients, repeated_times = self.select_clients_with_prob(seed=round_i) 
            else:
                selected_clients = self.select_clients(seed=round_i)
                repeated_times = None

            # Solve minimization locally
            #调用base.py中的local_train（）
            en_solns, stats,clients_sub,clients_num,size,esize =self.local_train(round_i, selected_clients, self.latest_model,self.solution_diff_avg)
            print(size)
            print(esize)
            #print(size_ratio)
            #solns = self.decoded(en_solns,tables)
            if clients_num != 0:
                # Track communication cost
                self.metrics.extend_commu_stats(round_i, stats)

                # Update latest model
                self.solution_diff_avg = self.aggregate(en_solns,clients_num,repeated_times=repeated_times)
                print("diff:")
                print(self.solution_diff_avg)
                self.latest_model = self.latest_model -  self.solution_diff_avg
                print("global_model:")
                print(self.latest_model)
                self.optimizer.inverse_prop_decay_learning_rate(round_i)
            if len(clients_sub)>0:
                self.change_prob(clients_sub)
            print("COMMUNICATION SIZE:")
            print(size)
            print("/n")
            train_acc.append(train_states['acc']*100)
            train_loss.append(train_states['loss'])
            test_acc.append(train_states['acc']*100)
            test_loss.append(train_states['loss'])
            size_ratios.append(size_ratio*100)
            sum_size += size
            sum_bsize+=before_size
        # Test final model on train data
        self.test_latest_model_on_traindata(self.num_round)
        self.test_latest_model_on_evaldata(self.num_round)
        print("sum_size:")
        print(sum_size)
        print("sum_bsize:")
        print(sum_bsize)
        # Save tracked information
        with open("./result/exp/train_acc0.23.pkl","wb") as f:
            pickle.dump(train_acc,f)
        with open("./result/exp/train_loss0.23.pkl","wb") as f:
            pickle.dump(train_loss,f)
        with open("./result/exp/test_acc0.23.pkl","wb") as f:
            pickle.dump(test_acc,f)
        with open("./result/exp/test_loss0.23.pkl","wb") as f:
            pickle.dump(test_loss,f)
        with open("./result/exp/size_ration0.23.pkl","wb") as f:
            pickle.dump(size_ratios,f)
        with open("./result/exp/size0.23.pkl","wb") as f:
            pickle.dump(sum_size,f)
        with open("./result/exp/before_size0.23.pkl","wb") as f:
            pickle.dump(sum_bsize,f)
        self.metrics.write()

    def decoded(self,en_solns=None,tables=None):
        solns=[]
        for i in range(len(tables)):
            update_value=[]
            d = pow(2,math.ceil(math.log(len(tables[i]),2)))
            lenth = np.array(en_solns[i][1])
            en_soln = np.array(en_solns[i][2])
            table = np.array(tables[i])

            #解码
            index = en_soln%d
            update_value.append(table[int(index)])
            value = en_soln//d
            for n in range(1,lenth):
                index = value%d
                update_value.append(table[int(index)])
                value = value//d
            solns.append([float(en_solns[i][0]),torch.Tensor(update_value)])  
            print("解压后：")
            print(torch.Tensor(update_value))
        
        return solns

    def compute_prob(self):
        probs = []
        for c in self.clients:
            probs.append(len(c.train_data))
        #return np.array(probs)/sum(probs)
        return torch.Tensor(probs)*100
    
    def change_prob(self,clients_sub):
        for c in range(len(clients_sub)):
            self.prob[clients_sub[c]] -= 100
        print("概率表")
        print(self.prob)

    def select_clients_with_prob(self, seed=1):
        num_clients = min(self.clients_per_round, len(self.clients))
        np.random.seed(seed)
        index = torch.multinomial(self.prob,num_clients,replacement=False)
        index = index.numpy()
        #index = np.random.choice(len(self.clients), num_clients,replace=False, p=self.prob)
        index = sorted(index.tolist())

        select_clients = []
        select_index = []
        repeated_times = []
        for i in index:#对选中的几个client进行操作
            if i not in select_index:
                select_clients.append(self.clients[i])
                select_index.append(i)
                repeated_times.append(1)
            else:
                repeated_times[-1] += 1
        return select_clients, repeated_times

    def aggregate(self, solns,clients_num, **kwargs):
        averaged_solution = torch.zeros_like(self.latest_model)
        # averaged_solution = np.zeros(self.latest_model.shape)
        size = 0
        if self.simple_average:
            for i, (num_sample, local_solution) in enumerate(solns):
                averaged_solution += local_solution
                local_solution_1d = torch.reshape(local_solution,(1,-1))
                for params in local_solution_1d:
                    size += sys.getsizeof(params)
            averaged_solution /= clients_num
        else:
            for num_sample, local_solution in solns:
                averaged_solution += num_sample * local_solution
            averaged_solution /= self.all_train_data_num
            averaged_solution *= (100/clients_num)
        # averaged_solution = from_numpy(averaged_solution, self.gpu)
        return averaged_solution.detach()

